### -*- coding: utf-8 -*-
#include libraries
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pylab as plt
import threading 
from tkinter import *
from PIL import ImageTk,Image
import serial.tools.list_ports
import csv
import functools
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import time as app_time
import datetime
import pyautogui
from numpy import genfromtxt
from tkinter import ttk, filedialog
from tkinter.filedialog import askopenfile
import os


app_running = True;
m_time_string = "Time " #intialize string for time and date




m_cmap = ['coolwarm', 'coolwarm_r', 'Spectral', 'Spectral_r', 'YlGnBu','mako', 'BuPu','rocket', 'YlOrBr']
m_dd_hm_str=m_cmap[0]
###initialize global variables and parameter
m_app_type="Foot Weight Distribution";
row=16;
column=8;
plane=5;
m_time=0;
###Read Buffer
r_foot_buf_read=np.zeros((plane,row,column)) ### Right Foot buffer reads 10 values in a second
l_foot_buf_read=np.zeros((plane,row,column)) ### Left Foot buffer reads 10 values in a second

###Initilization 
r_foot_buf_initial=np.zeros((row,column)) ### Right Foot buffer reads 10 values in a second
l_foot_buf_initial=np.zeros((row,column)) ### Right Foot buffer reads 10 values in a second

###Avg buff
r_foot_buf_avg=np.zeros((row,column)) ### Right Foot buffer reads 10 values in a second
l_foot_buf_avg=np.zeros((row,column)) ### Right Foot buffer reads 10 values in a second


###Display Buffer
r_foot_buf_display=np.zeros((row,column)) ### Right Foot buffer Display 10 values in a second
l_foot_buf_display=np.zeros((row,column)) ### Left Foot buffer Display 10 values in a second



###Input Output Serial Communication Port Configuration 
ports=serial.tools.list_ports.comports()
serialObj = serial.Serial()
serialObj.port = '/dev/ttyACM0'
serialObj.baudrate = 115200
serialObj.open()

#Function receive data from input port (serial):
def heat_map():
    app.update() #use to update the screen
    #if foot start marker , start storing data to the buffer right and left 
    #the buffer will get updated 10 foot samples in a second
#    while '$$$' not in line:    
    #    "Arduino mega send the data from 16 ADC through RS232 protocol to USB serial that can be further processed in pyhton"
    #    "Data of each analog is receive serialy and decode and save in a variable."
    l_row=0;
    l_col=0;
    l_plane=0;
    initial=0;
    #tmp=np.ones((row,column))
    global r_foot_buf_display;           
    while app_running:
        app.update() #use to update the screen
        #print("Packet start")
        raw_rcv = serialObj.readline() #reading line of 8 elements
        # Converting to Int and spliting into array of 8 length
        raw_rcv_tmp = raw_rcv.decode('utf').rstrip('\n').rstrip('\r').rstrip('').split(',') 
        if  raw_rcv_tmp == ['$$$$']:
            l_row=0;
        if (np.shape(raw_rcv_tmp)) == (8,):
            r_foot_buf_read[l_plane][l_row]=raw_rcv_tmp
            l_row=l_row+1;
            if (l_row==16):
                l_plane=l_plane+1;
                l_row=0;
            if (l_plane == 5):
                r_foot_buf_initial=np.average(r_foot_buf_read, axis=0)
                l_plane =0;
                r_foot_buf_avg=np.average(r_foot_buf_read, axis=0)
                r_foot_buf_display=r_foot_buf_avg.astype(int)
                #tmp=tmp.astype(int)
                #tmp=tmp+1
                ax1.clear()
                sns.heatmap(r_foot_buf_display, ax=ax1, linewidth = .1 ,cmap = 'coolwarm', cbar=False, annot = True, fmt="d")
                hm_canvas.draw()           
        
                
#function that takes data statically from Csv File 
def btn_static():
    app.update() #use to update the screen
    global m_user_analysis_str;
    global m_choise_hm;
    m_user_analysis_str="";
    #if foot start marker , start storing data to the buffer right and left 
    #the buffer will get updated 10 foot samples in a second
#    while '$$$' not in line:    
    #    "Arduino mega send the data from 16 ADC through RS232 protocol to USB serial that can be further processed in pyhton"
    #    "Data of each analog is receive serialy and decode and save in a variable."
    file = filedialog.askopenfile(title="Please Select Right Foot CSV File",mode='r', filetypes=[('Right Foot', '*.csv')])
    if file:
        filepath = os.path.abspath(file.name)
        r_foot_buf_display = genfromtxt(filepath, delimiter=',' ,dtype=int)
    
    file = filedialog.askopenfile(title="Please Select Left Foot CSV File", mode='r', filetypes=[('Left Foot', '*.csv')])
    if file:
        filepath = os.path.abspath(file.name)
        l_foot_buf_display = genfromtxt(filepath, delimiter=',' ,dtype=int)
        l_foot_buf_display = np.rot90(np.rot90((l_foot_buf_display)));
    app.update() #use to update the screen
    Label(app,text="Left Foot:",bg='#002060',fg="lightgreen",font=("Arial",20,'bold')).place(x=50,y=150)
    Label(app,text="Average  " +  (np.average(l_foot_buf_display)).astype('str'),bg='#002060',fg="lightgreen",font=("Arial",14,'bold')).place(x=50,y=190)
    Label(app,text="Variance  " +  (np.var(l_foot_buf_display)).astype('str'),bg='#002060',fg="lightgreen",font=("Arial",14,'bold')).place(x=50,y=210)
    Label(app,text="StD " +  (np.std(l_foot_buf_display)).astype('str'),bg='#002060',fg="lightgreen",font=("Arial",14,'bold')).place(x=50,y=230)
    Label(app,text="Right Foot:",bg='#002060',fg="lightgreen",font=("Arial",20,'bold')).place(x=50,y=350)
    Label(app,text="Average  " +  (np.average(r_foot_buf_display)).astype('str'),bg='#002060',fg="lightgreen",font=("Arial",14,'bold')).place(x=50,y=390)
    Label(app,text="Variance  " +  (np.var(r_foot_buf_display)).astype('str'),bg='#002060',fg="lightgreen",font=("Arial",14,'bold')).place(x=50,y=410)
    Label(app,text="StD " +  (np.std(r_foot_buf_display)).astype('str'),bg='#002060',fg="lightgreen",font=("Arial",14,'bold')).place(x=50,y=430)
    ax1.cla()
    ax2.cla()
    #sns.heatmap(r_foot_buf_display, ax=ax1, linewidth = .1 , cbar=False, annot = True, fmt="d")
    #sns.heatmap(l_foot_buf_display, ax=ax2, linewidth = .1 , cbar=False, annot = True, fmt="d")
    sns.heatmap(r_foot_buf_display, ax=ax1, linewidth = .1 ,cmap = m_dd_hm_str, cbar=False, annot = True, fmt="d")
    sns.heatmap(l_foot_buf_display, ax=ax2, linewidth = .1 ,cmap = m_dd_hm_str, cbar=False, annot = True, fmt="d")
    hm_canvas.draw()
    ax1.set_title('Heatmap with ' + m_dd_hm_str + ' Colormap')  
    
    ####################################################################


#----------------Clocktime and date update function after every 1 seconds-----
def clock_time():
    app.update()
    while app_running:
        app.update()
        time=datetime.datetime.now()
        time = (time.strftime("%d  %b, %Y           %I:%M:%S  %p"))
        m_time_string.set(time)
        app_time.sleep(.5)
        #app.after(1,clock_time)
        #heatmap.set_title('Heatmap with ' + m_dd_hm_str + ' Colormap')
        #app.after(5000, clock_time)

#----------------Save File Button -----------------
def save_file():
    m_name =  m_patient_name.get()
    m_age = m_patient_age.get()
    m_weight = m_patient_weight.get()
    time=datetime.datetime.now()
    m_time=time.strftime("%H:%M:%S")
    my_data = np.savetxt('./patient_data/'+m_time+' Right_foot '+m_name+'.csv', r_foot_buf_display, delimiter=',')
   

#-----------------HEAT MAP FUNCTION FOR SCREEN-------------------


def toggle():
    app.update()
    if btn_tg_fw_wa.config('relief')[-1] == 'sunken':
        btn_tg_fw_wa.config(relief="raised")
        print("Foot Weight Distribution")
        m_app_type='Foot Weight Distribution';

    else:
        btn_tg_fw_wa.config(relief="sunken")
        print("Walk Analysis")
        m_app_type='Foot Weight Distribution';


def exit_window():
    try:
        global app, hm_canvas
        hm_canvas.get_tk_widget().forget()
        app.destroy()
    except Exception as e:
        pass
        
def drop_down_menu_heatmap(m_choise_hm):
    global m_dd_hm_str
    m_dd_hm_str=variable.get()

   


#############GUI Work#####################



#-----------------MAIN CODE FOR BEGIN SCREEEN AND APP-------------
app = Tk()
app.title('UCERD Foot Analytics')    
app.geometry("1280x700")
app.configure(bg="black")
bg= ImageTk.PhotoImage(file="foot_design_pic_new.jpg")
canvas = Canvas(app, width=1280, height=700)
canvas.pack(fill=BOTH, expand=True)
canvas.create_image(0,0,image=bg, anchor=NW)

#-----------------MAIN SCREEN CANVAS INITIALIZER-----------------

fig = Figure();
ax1=fig.add_subplot(121)   #IMAGE SIZE, FIRST ROW, FIRST COLOUMN AND ONE FIGURE(111) 
ax2=fig.add_subplot(122)   #IMAGE SIZE, FIRST ROW, FIRST COLOUMN AND ONE FIGURE(111) 


fig.set_facecolor("#002060")# fACE COLOUR
#Creating Heat Map Foot Canvas
hm_canvas = FigureCanvasTkAgg(fig, master=app)  # A tk.DrawingArea.
hm_canvas.get_tk_widget().place(x = 500, y=50, width = 800, height = 520)# DIMESIONS OF DRAWING AREA
hm_canvas.draw()# THEN DRAW



#-----------------Main screen button for heat map----------------
btn_heat_map = Button(text='          HEAT MAP         ', command=heat_map, bg='#70AD47',fg='white',font= 10)
btn_save = Button(text='          SAVE CSV         ', command=save_file, bg='#70AD47',fg='white',font= 10)
btn_static = Button(text='Static Analysis', command=btn_static, bg='#70AD47',fg='white',font= 10)
btn_dynamic= Button(text='Dynamic Analysis', command=save_file, bg='#70AD47',fg='white',font= 10)
Patient_Name = Button(text='Patient Name:',  bg='#70AD47',fg='white',font= 5)
Age = Button(text='Age:',  bg='#70AD47',fg='white',font= 5)
Weight = Button(text='Weight:',  bg='#70AD47',fg='white',font= 5)

canvas.create_window(200, 600, window=btn_static)
canvas.create_window(400, 600, window=btn_dynamic)
canvas.create_window(500, 650, window=btn_heat_map)
canvas.create_window(800, 650, window=btn_save)
canvas.create_window(80, 60, window=Patient_Name)
canvas.create_window(80, 100, window=Age)
canvas.create_window(80, 140, window=Weight)

#### User Data Input Entery
m_patient_name = Entry(app, width=30)
m_patient_name.place(x=170, y=50)  # Adjust the y-coordinate to prevent overlap
m_patient_name.insert(0, "Patient Name:") 

m_patient_age = Entry(app, width=30)
m_patient_age.place(x=170, y=90)  # Adjust the y-coordinate as needed
m_patient_age.insert(0, "Age:")

m_patient_weight = Entry(app, width=30)
m_patient_weight.place(x=170, y=120)  # Adjust the y-coordinate as needed
m_patient_weight.insert(0, "Weight:")

###-----------------Main screen time and data slot alocation----------

#-----------------Main screen time and data slot alocation----------
app.after(500,clock_time)# functions run after 500 ms here
m_time_string= StringVar()#intialize string for time and date
#m_app_type=StringVar()

lbl = Label(app, textvariable=m_app_type, bg= '#4472C4',fg="white", font=("Arial",20)).place(x=10,y=15) # initialize 


btn_close = Button(text=' X ', command=exit_window, bg='#70AD47',fg='white',font= 10)
canvas.create_window(1100, 25, window=btn_close)



# setting variable for Integers
variable = StringVar()
variable.set(m_cmap[0])

# creating widget
dropdown = OptionMenu(
    app,
    variable,
    *m_cmap,
    command=drop_down_menu_heatmap
)


# positioning widget
dropdown.pack(expand=True)
dropdown.place(x=200,y=630)


app.protocol("WM_DELETE_WINDOW", exit_window)
app.mainloop()
